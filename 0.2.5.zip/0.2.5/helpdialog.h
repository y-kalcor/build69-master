
#pragma once
class CHelpDialog
{
private:

	IDirect3DDevice9 *m_pD3DDevice;

public:
	CHelpDialog(IDirect3DDevice9 *pD3DDevice);
	~CHelpDialog() {};

	void Draw();
};
