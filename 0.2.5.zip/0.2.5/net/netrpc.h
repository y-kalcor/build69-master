#pragma once

//----------------------------------------------------

void RegisterRPCs(RakClientInterface *);
void UnRegisterRPCs(RakClientInterface *);

//----------------------------------------------------
