#pragma once
#ifndef SAMPCLI_SCRIPTRPC_H
#define SAMPCLI_SCRIPTRPC_H

//----------------------------------------------------

void RegisterScriptRPCs(RakClientInterface* pRakClient);
void UnRegisterScriptRPCs(RakClientInterface* pRakClient);

//----------------------------------------------------

#endif