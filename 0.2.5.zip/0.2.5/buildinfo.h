#ifndef _BUILDINFO_H
#define _BUILDINFO_H 1

#pragma once

#define DEVELOPER				"sa-mp"
#define SAMP_VERSION			"0.2.5-zyronix"
#define BUILD_INFO				"SA:MP-" SAMP_VERSION "-" DEVELOPER "-" __DATE__ "-" __TIME__

#endif